<template>

  <a-row style="padding:5% 0">
    <a-col :push="6" :span="12">
      <a-card :bordered="false">

        <a-form class="permission-form" :form="form" @submit="queryData">
          <a-row type="flex" justify="space-around">
            <a-col :span="20">
              <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材编号：">
                <a-input placeholder="器材编号" v-decorator="['material_code']" />
              </a-form-item>
              <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材名称：">
                <a-input placeholder="器材名称" disabled v-decorator="['material_name']" />
              </a-form-item>
              <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="库位编号:">
                <a-input placeholder="库位编号" disabled v-decorator="['location_code']" />
              </a-form-item>
            </a-col>
            <a-col :span="4">
              <a-button size="large" class="btnStyle queryBtn" html-type="submit" type="primary">查询
              </a-button>
            </a-col>
            <a-col :span="24">
              <a-form-item>
                <s-table :customRow="customRow" bordered ref="table" size="default" :pageSize="3"
                  :columns="columns" :data="loadData">
                </s-table>
              </a-form-item>
            </a-col>
            <a-col :span="24">
              <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="操作口:">
                <a-select v-decorator="['org_position']">
                  <a-select-option v-for="item in statusDic" :key="item" :value="item">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :span="24">
              <a-row type="flex" justify="space-around">
                <a-col :span="6">
                  <a-button size="large" class="btnStyle" @click="taskDown" type="primary">下架
                  </a-button>
                </a-col>
                <a-col :span="6">
                  <a-button size="large" class="btnStyle" type="default" @click="clearData">取消
                  </a-button>
                </a-col>
              </a-row>
            </a-col>
          </a-row>
        </a-form>
      </a-card>
    </a-col>
  </a-row>

</template>

<script>
import pick from 'lodash.pick'
import { STable } from '@/components'
import { getDataByInventory } from '@/api/Inventory'
import { TaskXInsert } from '@/api/TaskX'
import { getDropDownListBy } from '@/api/global'
// import { palletUpDown } from '@/api/InvenMaterialLocationmap'

const columns = [
  {
    title: '器材编号',
    dataIndex: 'material_code'
  },
  {
    title: '器材名称',
    dataIndex: 'material_name'
  },
  {
    title: '库存数量',
    dataIndex: 'inventory_count'
  },
  {
    title: '载具号',
    dataIndex: 'pallet_code'
  },
  {
    title: '库位编号',
    dataIndex: 'location_code'
  }
]
export default {
  name: 'PalletDownShelf',
  components: {
    STable
  },
  data() {
    return {
      columns,
      // 编辑form
      form: this.$form.createForm(this),
      // 动态栅格
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 }
      },
      startTime: '1900-01-01',
      endTime: '3000-01-01',
      queryParam: { material_code: 9999999999 },
      loadData: parameter => {
        parameter.startTime = this.startTime
        parameter.endTime = this.endTime
        return getDataByInventory(parameter, this.queryParam).then(res => {
          console.log(res)
          return res.result
        })
      },
      clickCurrent: {},
      statusDic: []
    }
  },
  methods: {
    customRow(record, index) {
      return {
        on: {
          // 鼠标单击行
          click: event => {
            this.$refs.table.refresh(true)
            // 点击入库单给其行设置高亮颜色
            event.currentTarget.parentNode.querySelectorAll('tr').forEach(item => {
              item.style.background = 'white'
            })
            this.clickCurrent = record
            this.form.setFieldsValue(pick(record, ['material_name']))
            this.form.setFieldsValue(pick(record, ['location_code']))
            event.currentTarget.style.background = '#e6f7ff'
          }
        }
      }
    },
    clearData() {
      this.queryParam = { material_code: '', material_name: '', location_code: '' }
      this.form.setFieldsValue(pick(this.queryParam, ['material_code', 'material_name', 'location_code']))
    },
    queryData(e) {
      e.preventDefault()
      this.form.validateFields((err, values) => {
        if (!err) {
          this.queryParam = values
          console.log(this.queryParam)
          this.$refs.table.refresh(true)
        }
      })
    },
    // org_position
    taskDown() {
      console.log(this.clickCurrent)
      TaskXInsert(this.clickCurrent).then(res => {
        if (res.status) {
          this.$message.success(res.message)
        } else {
          this.$message.warn(res.message)
        }
      })
    },
    bindData() {},
    getDic() {
      getDropDownListBy('operation').then(res => {
        this.statusDic = res.result.anything
      })
    }
  },
  created() {
    this.getDic()
  },
  watch: {}
}
</script>

<style lang="less" scoped>
.permission-form {
  :deep(.permission-group) {
    margin-top: 0;
    margin-bottom: 0;
  }
}
.btnStyle {
  width: 100%;
}
.queryBtn {
  height: 80%;
}
</style>
