<template>
  <a-card :bordered="false">
    <!-- 检索相关 -->
    <div class="table-page-search-wrapper">
      <a-form layout="inline" @submit="getDataBy" :form="formBy">
        <a-row :gutter="48">
          <a-col :md="5" :sm="24">
            <a-form-item label="盘点单号：">
              <a-input placeholder="请输入单号" v-decorator="['checkCode']" />
            </a-form-item>
          </a-col>
          <a-col :md="5" :sm="24">
            <a-form-item label="状态">
              <a-select placeholder="请选择" v-decorator="['status']">
                <a-select-option v-for="item in statusDic" :key="item.key" :value="item.value">
                  {{ item.value }}
                </a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="选择时间：">
              <a-range-picker :placeholder="['开始时间', '结束时间']" v-model="dateVar"
                              @change="onChange" />
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button html-type="submit" type="primary">查询</a-button>
              <a-button style="margin-left: 8px" @click="clearSelectBy">重置</a-button>
              <a-button style="margin-left: 8px" type="primary" @click="addData">新增盘点单</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>
    <!-- 表格 -->
    <s-table bordered rowKey="checkId" :customRow="customRow" ref="table" size="default"
             :pageSize="5" :columns="columns" :data="loadData">
      <a-tag color="green" slot="status_display_value" slot-scope="text">{{ text }}</a-tag>
      <span slot="createTime" slot-scope="text">{{ text | moment }}</span>
      <span slot="action" slot-scope="text, record">
        <a v-if="record.status == 0" @click="updateStart(record)">开始盘点</a>
        <a v-if="record.status == 1" @click="updateEnd(record)">结束盘点</a>
        <a-divider v-if="record.status == 0" type="vertical" />
        <a v-if="record.status == 0" @click="updateGetValue(record)">编辑</a>
      </span>
    </s-table>
    <div>
      <a-button type="primary" @click="addDataDetail" v-if="outorderStatus==0">新增盘点明细
      </a-button>
    </div>
    <!-- <a-divider /> -->
    <s-table rowKey="checkDetailId" bordered ref="detailTable" size="default" :pageSize="5"
             :columns="detailColumns" :data="loadDataDetail">
      <a-tag color="green" slot="status_display_value" slot-scope="text">{{ text }}</a-tag>
      <span slot="createTime" slot-scope="text">{{ text | moment }}</span>
      <span slot="action" slot-scope="text, record">
        <a @click="updateGetValueDetail(record)" v-if="record.status == 0">编辑</a>
        <a-divider v-if="record.status == 0" type="vertical" />
        <a href="javascript:;" v-if="record.status == 0"
           @click="delDataMethod(record,'tableContent')">删除</a>
        <a @click="updatePanDetail(record)" v-if="record.status == 1">盘点</a>
        <a-divider v-if="record.status == 1" type="vertical" />
        <a href="javascript:;" v-if="record.status == 1"
           @click="endCheck(record)">完成</a>
      </span>
    </s-table>

    <!-- 编辑 -->
    <a-modal title="编辑" style="top: 20px" :width="800" v-model="visibleUpdate" @ok="updateSure">
      <a-form class="permission-form" :form="formUpdate">
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="器材编号">
          <a-input placeholder="主键"
                   v-decorator="['checkId']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="盘点单号">
          <a-input placeholder="盘点单号"
                   v-decorator="['checkCode']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="盘点单号">
          <a-input placeholder="盘点单号"
                   v-decorator="['status']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="盘点内容">
          <a-input placeholder="盘点内容"
                   v-decorator="['heSuanKeMu', { rules: [{ required: true, validator, message: '请输入盘点内容!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="盘点类型">
          <a-select placeholder="请选择"
                    v-decorator="['panKuYiJu',{ rules: [{ required: true, validator, message: '请选择盘点类型!' }] }]">
            <a-select-option v-for="item in orderTypeDic" :key="item" :value="item">
              {{ item }}
            </a-select-option>
          </a-select>
        </a-form-item>
      </a-form>
    </a-modal>
    <!-- 编辑明细 -->
    <a-modal title="编辑" style="top: 20px" :width="800" v-model="visibleUpdateDetail"
             @ok="updateSureDetail">
      <a-form class="permission-form" :form="formUpdateDetail">
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="盘点单号">
          <a-input placeholder="盘点单号"
                   v-decorator="['checkDetailId']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="盘点单号">
          <a-input placeholder="盘点单号"
                   v-decorator="['checkCode']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材编号">
          <a-input placeholder="器材编号"
                   v-decorator="['materialCode', { rules: [{ required: true, validator, message: '请输入器材编号!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材名称">
          <a-input placeholder="器材名称" disabled
                   v-decorator="['materialName', { rules: [{ required: true, validator, message: '请输入器材名称!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="价格">
          <a-input placeholder="价格" disabled
                   v-decorator="['materialPrice', { rules: [{ required: true, validator, message: '请输入价格!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="批次">
          <a-input placeholder="批次" disabled
                   v-decorator="['batch', { rules: [{ required: true, validator, message: '请输入批次!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="库存数量">
          <a-input placeholder="库存数量" disabled
                   v-decorator="['inventoryCount', { rules: [{ required: true, validator, message: '请输入库存数量!' }] }]" />
        </a-form-item>
      </a-form>
    </a-modal>
    <!-- 盘点明细 -->
    <a-modal title="盘点" style="top: 20px" :width="800" v-model="panDetail"
             @ok="updateSureDetail">
      <a-form class="permission-form" :form="formUpdateDetail">
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="盘点单号">
          <a-input placeholder="盘点单号"
                   v-decorator="['checkDetailId']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" hidden :wrapperCol="wrapperCol" label="盘点单号">
          <a-input placeholder="盘点单号"
                   v-decorator="['checkCode']" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材编号">
          <a-input placeholder="器材编号" disabled
                   v-decorator="['materialCode', { rules: [{ required: true, validator, message: '请输入器材编号!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材名称">
          <a-input placeholder="器材名称" disabled
                   v-decorator="['materialName', { rules: [{ required: true, validator, message: '请输入器材名称!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="价格">
          <a-input placeholder="价格" disabled
                   v-decorator="['materialPrice', { rules: [{ required: true, validator, message: '请输入价格!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="批次">
          <a-input placeholder="批次" disabled
                   v-decorator="['batch', { rules: [{ required: true, validator, message: '请输入批次!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="库存数量">
          <a-input placeholder="库存数量" disabled
                   v-decorator="['inventoryCount', { rules: [{ required: true, validator, message: '请输入库存数量!' }] }]" />
        </a-form-item>
        <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol" label="库存数量">
          <a-input placeholder="盘点数量"
                   v-decorator="['checkCount', { rules: [{ required: true, validator, message: '请输入盘点数量!' }] }]" />
        </a-form-item>
      </a-form>
    </a-modal>
    <!-- 新增出库单 -->
    <a-modal title="新增盘点单" style="top: 20px" :width="800" v-model="visibleAdd" @ok="addDataSure">
      <a-form class="permission-form" :form="formAdd">
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="盘点内容">
          <a-input placeholder="盘点内容"
                   v-decorator="['heSuanKeMu', { rules: [{ required: true, validator, message: '请输入盘点内容!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="盘点类型">
          <a-select placeholder="请选择"
                    v-decorator="['panKuYiJu',{ rules: [{ required: true, validator, message: '请选择盘点类型!' }] }]">
            <a-select-option v-for="item in orderTypeDic" :key="item" :value="item">
              {{ item }}
            </a-select-option>
          </a-select>
        </a-form-item>
      </a-form>
    </a-modal>
    <!-- 新增出库明细 -->
    <a-modal title="新增盘点明细" style="top: 20px" :width="800" v-model="visibleAddDetail"
             @ok="addDataSureDetail">
      <a-form class="permission-form" :form="formAddDetail">
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材编号">
          <a-input placeholder="器材编号" @keydown.enter="queryData"
                   v-decorator="['materialCode', { rules: [{ required: true, validator, message: '请输入器材编号!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="器材名称">
          <a-input placeholder="器材名称" disabled
                   v-decorator="['materialName', { rules: [{ required: true, validator, message: '请输入器材名称!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="价格">
          <a-input placeholder="价格" disabled
                   v-decorator="['materialPrice', { rules: [{ required: true, validator, message: '请输入价格!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="质量等级">
          <a-input placeholder="质量等级" disabled
                   v-decorator="['materialName', { rules: [{ required: true, validator, message: '请输入质量等级!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="批次">
          <a-input placeholder="批次" disabled
                   v-decorator="['batch', { rules: [{ required: true, validator, message: '请输入批次!' }] }]" />
        </a-form-item>
        <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="库存数量">
          <a-input placeholder="库存数量" disabled
                   v-decorator="['inventoryCount', { rules: [{ required: true, validator, message: '请输入库存数量!' }] }]" />
        </a-form-item>
      </a-form>
    </a-modal>
  </a-card>
</template>

<script>
import pick from 'lodash.pick'
import { STable } from '@/components'
import storage from 'store'
import { getPage, saveCheck, updateCheck, getPageDetail, getMaterial, saveCheckDetail, updateCheckDetail } from '@/api/CheckAPI'
import { getDataBy, delData, submitStatus } from '@/api/OutOrder'
import { delDataDetail } from '@/api/OutOrderDetail'
import QRCode from 'qrcode'
// import { h } from 'vue'
import JsBarcode from 'jsbarcode'
import * as XLSX from 'xlsx'

// 表头
const columns = [
  {
    title: '盘点单号',
    dataIndex: 'checkCode'
  },
  {
    title: '盘点内容',
    dataIndex: 'heSuanKeMu'
  },
  {
    title: '盘库依据',
    dataIndex: 'panKuYiJu'
  },
  {
    title: '盘点状态',
    dataIndex: 'statusDescribe'
  },
  {
    title: '创建人',
    dataIndex: 'creator'
  },
  {
    title: '创建时间',
    dataIndex: 'createTime'
  },
  {
    title: '修改人',
    dataIndex: 'updater'
  },
  {
    title: '修改时间',
    dataIndex: 'updateTime'
  },
  {
    title: '操作',
    width: '160px',
    dataIndex: 'action',
    scopedSlots: { customRender: 'action' }
  }
]

const detailColumns = [
  {
    title: '器材编号',
    dataIndex: 'materialCode'
  },
  {
    title: '器材名称',
    dataIndex: 'materialName'
  },
  {
    title: '价格',
    dataIndex: 'materialPrice'
  },
  {
    title: '批次',
    dataIndex: 'batch'
  },
  {
    title: '库存数量',
    dataIndex: 'inventoryCount'
  },
  {
    title: '盘点数量',
    dataIndex: 'checkCount'
  },
  {
    title: '状态',
    dataIndex: 'statusDescribe'
  },
  {
    title: '创建人',
    dataIndex: 'creator'
  },
  {
    title: '创建时间',
    dataIndex: 'create_time'
  },
  {
    title: '操作',
    width: '110px',
    dataIndex: 'action',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  name: 'InStorageBills',
  components: {
    STable
  },
  data() {
    return {
      orderTypeDic: ['物料盘点', '托盘/料箱盘点'],
      visibleGetGoods: false,
      printTitle: '',
      print: {
        id: 'printArea',
        popTitle: '&nbsp' // 打印配置页上方标题
      },
      // 打印出库单预览弹出框是否显示
      visiblePrintView: false,
      // 添加模态框是否显示
      visibleAdd: false,
      // 更新模态框是否显示
      visibleUpdate: false,
      formGetGoods: this.$form.createForm(this),
      // 打印出库单form
      printView: this.$form.createForm(this),
      // 编辑form
      formUpdate: this.$form.createForm(this),
      formUpdateDetail: this.$form.createForm(this),
      // 条件查询form
      formBy: this.$form.createForm(this),
      // 新增form
      formAdd: this.$form.createForm(this),
      // 新增form
      formAddDetail: this.$form.createForm(this),
      // 出库单查询参数
      queryParam: {},
      // 出库明细查询参数
      queryParamDetail: {},
      startTime: '1900-01-01',
      endTime: '3000-01-01',
      dateVar: ['', ''],
      checkCodeNow: '',
      detailStatus: 0,
      // 表头
      columns,
      detailColumns,
      printData: [],
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        parameter.startTime = this.startTime
        parameter.endTime = this.endTime
        this.checkedData = null
        this.outorderStatus = null

        // this.queryParamDetail = { out_order_id: '就是让你查不到' }
        // this.loadDataDetail({ pageNo: 1, pageSize: 3 })
        return getPage(parameter, this.queryParam).then(res => {
          return res.result
        })
      },
      loadDataDetail: parameter => {
        this.checkCodeNow = this.queryParamDetail.checkCode
        return getPageDetail(parameter, this.queryParamDetail).then(res => {
          return res.result
        })
      },
      // 状态字典列表
      statusDic: [
        {
          key: 0,
          value: '已创建'
        }, {
          key: 1,
          value: '盘点中'
        }, {
          key: 2,
          value: '已完成'
        }
      ],
      // 动态栅格
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 }
      },
      visibleAddDetail: false,
      validator: (rule, value, cbfn) => {
        // console.log(rule, value, cbfn)
        if (!value) {
          cbfn('请输入有效值')
        } else if (!value.trim().length) {
          cbfn('请输入有效值')
        }
        cbfn()
      },

      checkedData: null,
      outorderStatus: null,
      visibleUpdateDetail: false,
      panDetail: false,
      order_count: 0,
      inventory_count: 0
    }
  },
  computed: {
    //  定义导出的EXCEL表头数据
    titleArr() {
      const arr = []
      this.columns.map(item => {
        arr.push(item.title)
      })
      return arr
    }
  },

  methods: {
    submitStatus(record) {
      record.status = '待审核'
      submitStatus(record).then(res => {
        if (res.status) {
          this.$message.success(res.message)
          this.$refs.table.refresh(true)
        } else {
          this.$message.warn(res.message)
        }
      })
    },
    testInt() {
      const orderCount = this.formAddDetail.getFieldValue('order_count')
      if (orderCount < 0 || orderCount === undefined || orderCount % 1 !== 0) {
        this.formAddDetail.setFields({
          order_count: { value: '', errors: [{ message: '请输入正整数', field: 'order_count' }] }
        })
      }
    },
    onChange(date, dateString) {
      this.startTime = dateString[0]
      this.endTime = dateString[1]
      this.dateVar = [this.startTime, this.endTime]
    },
    queryData(e) {
      debugger
      e.preventDefault()
      const materialCodeTemp = this.formAddDetail.getFieldValue('materialCode')
      getMaterial({ material_code: materialCodeTemp }).then(res => {
        if (res.status) {
          console.log(res)
          this.$nextTick(() => {
            this.formAddDetail.setFieldsValue(pick(res.result[0], ['materialName', 'materialPrice', 'batch', 'inventoryCount']))
          })
        } else {
          this.$nextTick(() => {
            this.formAddDetail.setFieldsValue(pick({
              materialName: '',
              materialPrice: '',
              batch: '',
              inventoryCount: ''
            }, ['materialName', 'materialPrice', 'batch', 'inventoryCount']))
          })
          this.$message.warn(res.message)
        }
      })
    },
    // 新增出库单生辰出库单号
    // create_out_order_id() {
    //   createOutOrderId().then(res => {
    //     console.log(res)
    //     if (res.status) {
    //       this.formAdd.setFieldsValue(pick({ out_order_id: res.result }, ['out_order_id']))
    //     } else {
    //       this.$message.warn(res.message)
    //     }
    //   })
    // },
    // 导出EXCEL
    ToDoExcel() {
      // 屈经理说单独写接口
      getDataBy({ pageNo: 1, pageSize: 1000000 }, this.queryParam).then(res => {
        console.log(res)
        // 定义表格数据
        const arr = []
        res.result.anything.map(item => {
          arr.push([
            item.car_no,
            item.create_time,
            item.creator,
            item.out_order_id,
            item.order_type,
            item.org_order,
            item.status,
            item.udf01,
            item.udf02,
            item.udf03,
            item.udf04,
            item.udf05,
            item.update_time,
            item.updater
          ])
        })
        // 调用导出EXCEL的方法
        this.$ToDoExcel(`出库单`, this.titleArr, arr)
      })
    },
    // 导入excel
    uploadXLSX(info) {
      const { files } = event.target
      const vali = /\.(xls|xlsx)$/
      if (files.length <= 0) {
        // 如果没有文件名
        return false
      }
      if (!vali.test(files[0].name.toLowerCase())) {
        this.$Message.error('上传格式不正确，请上传xls或者xlsx格式')
        return false
      }
      const file = event.target.files[0]
      const reader = new FileReader()
      console.log(file, 'file')

      reader.onload = e => {
        // 读取成功后result中的数据
        const data = e.target.result
        // 以base64方法读取 结果
        const workbook = XLSX.read(data, { type: 'binary' })
        // 获取数据的表名
        const sheetName = workbook.SheetNames[0]
        // workSheet 是该excel表格中的数据
        const sheet = workbook.Sheets[sheetName]
        console.log(sheet)
        for (const j in sheet) {
          if (j.search('1')) {
            for (let i = 0; i < this.columns.length; i++) {
              if (columns[i].title === sheet[j].h) {
                sheet[j].h = columns[i].dataIndex
                sheet[j].v = columns[i].dataIndex
                sheet[j].w = columns[i].dataIndex
              }
            }
          }
        }

        // 数据解析,输出JSON格式
        const jsonData = XLSX.utils.sheet_to_json(sheet)
        console.log(jsonData)
        // do something with jsonData
      }
      reader.readAsBinaryString(file)
    },
    // 处理excel导入的数据
    handleData(data) {
    },
    // 点击出库单行
    customRow(record, index) {
      return {
        on: {
          // 鼠标单击行
          click: event => {
            // 取到点击行的数据并取到出库明细
            this.queryParamDetail = { checkCode: record.checkCode }
            this.$refs.detailTable.refresh(true)
            // 点击出库单给其行设置高亮颜色
            event.currentTarget.parentNode.querySelectorAll('tr').forEach(item => {
              item.style.background = 'white'
            })
            this.checkedData = record
            this.outorderStatus = record.status
            event.currentTarget.style.background = '#e6f7ff'
          }
        }
      }
    },
    // 条件查询按钮点击事件
    getDataBy(e) {
      e.preventDefault()
      this.formBy.validateFields((err, values) => {
        if (!err) {
          this.queryParam = values
          this.$refs.table.refresh(true)
        }
      })
    },
    // 重置检索条件
    clearSelectBy() {
      this.startTime = '1900-01-01'
      this.endTime = '3000-01-01'
      this.dateVar = ['', '']
      this.queryParam = { out_order_id: '', status: '' }
      this.formBy.setFieldsValue(pick(this.queryParam, ['out_order_id', 'status']))
      this.$refs.table.refresh(true)
    },

    // 新增出库明细按钮点击事件
    addDataDetail(e) {
      if (this.checkedData === null) {
        this.$message.info('请先选择一个出库单！')
        return
      }
      this.visibleAddDetail = true
      setTimeout(() => {
        this.formAddDetail.setFieldsValue(pick(this.checkedData, ['out_order_id']))
      }, 1000)
    },
    // 确认新增出库明细点击事件
    addDataSureDetail(e) {
      e.preventDefault()
      this.formAddDetail.validateFields((err, values) => {
        if (!err) {
          values.creator = this.userInfo.user_name
          values.checkCode = this.checkCodeNow
          saveCheckDetail(values).then(res => {
            this.visibleAddDetail = false
            if (res.status) {
              this.$refs.detailTable.refresh(true)
              this.$message.success(res.message)
            } else {
              this.$message.warn(res.message)
            }
          })
        }
      })
    },

    // 新增按钮点击事件
    addData(e) {
      this.visibleAdd = true
    },
    // 确认新增点击事件
    addDataSure(e) {
      e.preventDefault()
      this.formAdd.validateFields((err, values) => {
        if (!err) {
          console.log(values)
          values.creator = this.userInfo.user_name
          saveCheck(values).then(res => {
            console.log(res)
            this.visibleAdd = false
            if (res.status) {
              this.$refs.table.refresh(true)
              this.$message.success(res.message)
            } else {
              this.$message.warn(res.message)
            }
          })
        }
      })
    },
    // 编辑按钮取值给模态框
    updateGetValue(record) {
      console.log(record)
      this.visibleUpdate = true
      console.log(record)
      this.$nextTick(() => {
        this.formUpdate.setFieldsValue(pick(record, ['checkId', 'checkCode', 'heSuanKeMu', 'warehouseName', 'panKuYiJu', 'status']))
      })
    },
    // 开始盘点
    updateStart(record) {
      record.updater = this.userInfo.user_name
      record.status = 1
      updateCheck(record).then(res => {
        console.log(res)
        if (res.status) {
          this.$refs.table.refresh(true)
          this.$message.success(res.message)
        } else {
          this.$message.warn(res.message)
        }
      })
    },
    // 结束盘点
    updateEnd(record) {
      record.updater = this.userInfo.user_name
      record.status = 2
      updateCheck(record).then(res => {
        console.log(res)
        if (res.status) {
          this.$refs.table.refresh(true)
          this.$message.success(res.message)
        } else {
          this.$message.warn(res.message)
        }
      })
    },
    endCheck(record) {
      if (record.checkCount == null || record.checkCount === '') {
        this.$message.warn('请先进行盘点!')
        return
      }
      record.updater = this.userInfo.user_name
      record.status = 2
      updateCheckDetail(record).then(res => {
        if (res.status) {
          this.$refs.table.refresh(true)
          this.$message.success(res.message)
        } else {
          this.$message.warn(res.message)
        }
      })
    },
    // 确定更新数据
    updateSure(e) {
      this.visibleUpdate = false
      e.preventDefault()
      this.formUpdate.validateFields((err, values) => {
        if (!err) {
          values.updater = this.userInfo.user_name
          console.log(values)
          updateCheck(values).then(res => {
            console.log(res)
            if (res.status) {
              this.$refs.table.refresh(true)
              this.$message.success(res.message)
            } else {
              this.$message.warn(res.message)
            }
          })
        }
      })
    },
    // 明细编辑按钮取值给模态框
    updateGetValueDetail(record) {
      console.log(record)
      this.detailStatus = record.status
      this.visibleUpdateDetail = true
      this.panDetail = false
      setTimeout(() => {
        this.formUpdateDetail.setFieldsValue(
          pick(record, ['checkDetailId', 'checkCode', 'materialCode', 'materialName', 'materialPrice', 'batch', 'inventoryCount', 'checkCount'])
        )
      }, 1000)
    },
    // 明细编辑按钮取值给模态框
    updatePanDetail(record) {
      this.detailStatus = record.status
      this.visibleUpdateDetail = false
      this.panDetail = true
      setTimeout(() => {
        this.formUpdateDetail.setFieldsValue(
          pick(record, ['checkDetailId', 'checkCode', 'materialCode', 'materialName', 'materialPrice', 'batch', 'inventoryCount', 'checkCount'])
        )
      }, 1000)
    },
    // 明细确定更新数据
    updateSureDetail(e) {
      e.preventDefault()
      this.formUpdateDetail.validateFields((err, values) => {
        console.log(err, values)
        if (!err) {
          values.updater = this.userInfo.user_name
          updateCheckDetail(values).then(res => {
            console.log(res)
            if (res.status) {
              this.$refs.detailTable.refresh(true)
              this.$message.success(res.message)
            } else {
              this.$message.warn(res.message)
            }
            this.visibleUpdateDetail = false
            this.panDetail = false
          })
        }
      })
    },
    // 删除数据
    delDataMethod(record, type) {
      const _this = this
      const modal = this.$confirm({
        content: '确定删除此数据吗？',
        okText: '删除',
        cancelText: '取消',
        onOk() {
          let temp = {}
          console.log(record)
          switch (type) {
            case 'tableTitle':
              temp = { out_order_id: record.out_order_id }
              delData(temp).then(res => {
                if (res.status) {
                  _this.$refs.table.refresh(true)
                  _this.$message.success(res.message)
                } else {
                  _this.$message.warn(res.message)
                }
              })
              break
            case 'tableContent':
              temp = { out_order_detail_id: record.out_order_detail_id }
              delDataDetail(temp).then(res => {
                if (res.status) {
                  _this.$refs.detailTable.refresh(true)
                  _this.$message.success(res.message)
                } else {
                  _this.$message.warn(res.message)
                }
              })
              break
            default:
          }
        },
        onCancel() {
          modal.destroy()
        }
      })
    },
    // 取检索条件的数据字典
    getDic() {
      // getDropDownListBy('OutOrderStatus').then(res => {
      //   console.log(res)
      //   this.statusDic = res.result.anything
      // })
      // getDropDownListBy('order_type').then(res => {
      //   this.orderTypeDic = res.result.anything
      // })
    },
    // 打印出库单按钮点击事件
    printInStorageBills() {
      this.visiblePrintView = true
      const storageName = storage.get('storageTypeText')
      this.printTitle = '器材仓库' + storageName + '出库单'
      this.$nextTick(() => {
        // 待生成条码的内容
        JsBarcode('#printBarCode', this.checkedData.out_order_id, {
          // 选择要使用的条形码类型
          format: 'CODE128',
          // 设置条之间的宽度
          width: 2,
          // 高度
          height: 40,
          // 是否在条形码下方显示文字
          displayValue: true,
          // 覆盖显示的文本       text: '456',

          // 使文字加粗体或变斜体
          fontOptions: 'bold italic',
          // 设置文本的字体
          font: 'fantasy',
          // 设置文本的水平对齐方式
          textAlign: 'center',
          // 设置文本的垂直位置
          textPosition: 'bottom',
          // 设置条形码和文本之间的间距
          textMargin: 5,
          // 设置文本的大小
          fontSize: 8,
          // 设置条和文本的颜色。
          lineColor: '#000',
          // 设置条形码周围的空白边距
          margin: 0
        })
        // console.log(this.printData)
        this.printData.forEach((item, index) => {
          const materialCode = (item.material_code + '_' + item.material_name + '_' + item.batch).toString()
          const opts = {
            errorCorrectionLevel: 'H', // 容错级别
            type: 'image/png', // 生成的二维码类型
            quality: 0.3, // 二维码质量
            margin: 1, // 二维码留白边距
            width: 1, // 宽
            height: 1, // 高
            text: materialCode, // 二维码内容
            color: {
              dark: '#333333', // 前景色
              light: '#fff' // 背景色
            }
          }

          const canvas = document.querySelectorAll('.materialCodeTu')
          // 将获取到的数据（val）画到msg（canvas）上
          QRCode.toCanvas(canvas[index], materialCode, opts, res => {
            console.log(res)
          })
        })
      })

      this.print.openCallback = () => {
        this.visiblePrintView = false
      }
      this.print.closeCallback = () => {
        this.visiblePrintView = false
      }
    },
    useqrcode() {
    }
  },
  created() {
    this.getDic()
    this.userInfo = storage.get('userInfo')
  },
  watch: {}
}
</script>

<style lang="less" scoped>
.permission-form {
  :deep(.permission-group) {
    margin-top: 0;
    margin-bottom: 0;
  }
}

#printArea {
  padding: 0 20px;

  .printTitle {
    font-size: 16px;
    font-weight: bolder;
    text-align: center;
    padding-top: 30px;
  }

  .ant-row {
    padding-top: 20px;

    .ant-col:not([col1]) {
      padding: 10px 0;
    }
  }
}

@page {
  size: auto;
  margin: 0mm;
  padding: 5mm;
}

.uploadContain {
  display: inline-block;
  position: relative;
}

.ant-form input[type='file'] {
  height: 32px;
  background: red;
  width: 102px;
  display: inline-block;
  position: absolute;
  z-index: 2;
  left: 8px;
  opacity: 0;
}
</style>
<style media="print">
#printTable {
  font-size: 25px !important;
}
</style>
