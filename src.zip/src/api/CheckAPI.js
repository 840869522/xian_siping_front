import request from '@/utils/request'

const api = {
  checkPage: '/check/page',
  checkPageDetail: '/check/detail/page',
  checkAdd: '/check/add',
  checkAddDetail: '/check/detail/add',
  checkUpdate: '/check/update',
  checkUpdateDetail: '/check/detail/update',
  deleteCheckDetail: '/check/detail/delete',
  queryMaterial: '/check/query/material'
}

export default api

export function getPage(parameter, queryParam) {
  return request({
    url: api.checkPage,
    method: 'post',
    data: queryParam,
    params: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function getMaterial(queryParam) {
  return request({
    url: api.queryMaterial,
    method: 'post',
    data: queryParam,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getPageDetail(parameter, queryParam) {
  return request({
    url: api.checkPageDetail,
    method: 'post',
    data: queryParam,
    params: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function saveCheck(values) {
  return request({
    url: api.checkAdd,
    method: 'post',
    data: values,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function saveCheckDetail(values) {
  return request({
    url: api.checkAddDetail,
    method: 'post',
    data: values,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function updateCheck(values, palletCode) {
  return request({
    url: api.checkUpdate,
    method: 'post',
    // params: { pageNo: 1, pageSize: 10 },
    data: values,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function updateCheckDetail(values, palletCode) {
  return request({
    url: api.checkUpdateDetail,
    method: 'post',
    // params: { pageNo: 1, pageSize: 10 },
    data: values,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function deleteCheckDetail(values) {
  return request({
    url: api.checkUpdateDetail,
    method: 'post',
    // params: { pageNo: 1, pageSize: 10 },
    data: values,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
